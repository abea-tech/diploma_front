import React, { useEffect, useState } from "react";
import { Button } from "@chakra-ui/react";
import { getAccessToken, setAccessTokenHeader, logout } from "./auth";

const Buttons = ({
  isUserLoggedIn,
  onOpenLoginModal,
  onOpenFirstModal,
  onOpenListDeliveriesModal,
  onOpenRegisterModal,
  onOpenTransportModal,
}) => {
  const handleLogin = (accessToken) => {
    setAccessTokenHeader(accessToken);
  };

  useEffect(() => {
    const accessToken = getAccessToken();
    if (accessToken) {
      handleLogin(accessToken);
    }
  }, []);

  const logOut = () => {
    logout();
    window.location.reload();
  };

  return (
    <>
      {isUserLoggedIn ? (
        <>
          <Button
            colorScheme="orange"
            marginTop="0"
            marginBottom="4"
            onClick={() => onOpenListDeliveriesModal("active")}
          >
            Активные
          </Button>
          <Button
            colorScheme="orange"
            marginTop="0"
            marginBottom="4"
            onClick={() => onOpenListDeliveriesModal("history")}
          >
            История
          </Button>
          <Button
            colorScheme="orange"
            marginTop="0"
            onClick={() => onOpenListDeliveriesModal("pending")}
            marginBottom="4"
          >
            В ожидании
          </Button>
          <Button
            colorScheme="orange"
            marginTop="0"
            onClick={onOpenFirstModal}
            marginBottom="4"
          >
            Маршрут
          </Button>
          <Button
            colorScheme="orange"
            marginTop="0"
            onClick={onOpenRegisterModal}
            marginBottom="4"
          >
            Водители
          </Button>
          <Button
            colorScheme="orange"
            marginTop="0"
            onClick={onOpenTransportModal}
            marginBottom="4"
          >
            Транспорт
          </Button>
          <Button
            colorScheme="orange"
            marginTop="0"
            marginBottom="4"
            onClick={logOut}
          >
            Выйти
          </Button>
        </>
      ) : (
        <Button
          colorScheme="orange"
          onClick={onOpenLoginModal}
          marginTop="0"
          marginBottom="4"
        >
          Войти
        </Button>
      )}
    </>
  );
};

export default Buttons;
